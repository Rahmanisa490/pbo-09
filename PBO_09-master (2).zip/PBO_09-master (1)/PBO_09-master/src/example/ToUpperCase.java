package example;

public class ToUpperCase {
    public static void main(String[] args) {
        String stringOri = "Walcome to Mangcodig";
        String stringUpper = stringOri.toUpperCase();
        System.out.println("Before using the toUpperCase method: " + stringOri);
        System.out.println("After using the toUpperCase method: " + stringUpper);
         
    }
}
