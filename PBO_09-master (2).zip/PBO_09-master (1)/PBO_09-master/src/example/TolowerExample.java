package example;

public class TolowerExample {
   public static void main(String[] args) {
    String stringOri = "Welcome to ngoding";
    String stringLower = stringOri.toLowerCase();
    System.out.println("Before using the tolowerCose methode: " + stringOri);
    System.out.println(("After using the tolowerCose methode: " + stringLower));
    
   } 
}
