package example;

public class ContainString {
    public static void main(String[] args) {
        String name = "Welcome to mangcoding";
        System.out.println("the result is: " + name.contains("Mangcoding"));
        System.out.println("the result is: " + name.contains("to"));
        System.out.println("the result is: " + name.contains("Hello"));
 
    }
}
