package example;

public class LengthString {
    public static void main(String[] args) throws Exception{
        String name = "Mangcoding";
        System.out.println("the result is: " + name.length());
    }
}
